﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;

namespace DeveloperInterviewPractical
{
    class Program
    {
        // ********   Instructons ***********
        // Follow the instructions in each region below to implement/change the code to meet the objective.
        // Thre are 7 implementation challenges to complete.
        // When you run the application, you will see console output with the status of each implementation.


        static void Main(string[] args)
        {
            // ***********  CAUTION *************
            // ***********  CAUTION *************
            // Do not modify this method other than uncommenting lines, otherwise the application will not run propperly.
            // ***********  CAUTION *************
            // ***********  CAUTION *************


            Console.WriteLine("**********  DrawHourglass Start **********");
            DrawHourglass();
            Console.WriteLine("**********  DrawHourglass End **********");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("**********  Fibonacci Sequence Start **********");
            FibonacciSequence(0, 1, 0);
            Console.WriteLine("**********  Fibonacci Sequence End **********");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("**********  Abstract Implementation Start **********");
            //Console.WriteLine("Enter a developers name, then enter:");
            //Developer d = new CSharpDeveloper(Console.ReadLine());
            //d.StartCoding();
            Console.WriteLine("**********  Abstract Implementation End **********");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("**********  Alert Service Start **********");
            //IAlertDAO alertDAO = new AlertDAO();
            //var alertService = new AlertService(alertDAO);
            //Guid alert1 = alertService.RaiseAlert();
            //Guid alert2 = alertService.RaiseAlert();
            //Console.WriteLine(alertService.GetAlertTime(alert1).ToString("o"));
            //Console.WriteLine(alertService.GetAlertTime(alert1).ToString("o"));
            Console.WriteLine("**********  Alert Service End **********");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("**********  Dog Breeds Start **********");
            DogBreeds.Add(new Dog() { BreedName = "Weimaraners", AverageWeight = 80 });
            DogBreeds.Add(new Dog() { BreedName = "Poodle", AverageWeight = 65 });
            DogBreeds.Add(new Dog() { BreedName = "Beagle", AverageWeight = 25 });
            DogBreeds.Add(new Dog() { BreedName = "Lab", AverageWeight = 95 });
            DogBreeds.Add(new Dog() { BreedName = "Affenpinschers", AverageWeight = 8 });
            DogBreeds.Add(new Dog() { BreedName = "Great Danes", AverageWeight = 155 });
            DogBreeds.Add(new Dog() { BreedName = "Boxer", AverageWeight = 70 });
            DogBreeds.Add(new Dog() { BreedName = "Bullmastiffs", AverageWeight = 120 });
            DogBreeds.Add(new Dog() { BreedName = "Maltese", AverageWeight = 5 });
            DogBreeds.Add(new Dog() { BreedName = "Samoyeds", AverageWeight = 50 });
            var breeds = GetDogsBiggerThanWeight(50);
            foreach (var b in breeds)
            {
                Console.WriteLine(b.BreedName + ": " + b.AverageWeight);
            }
            Console.WriteLine("**********  Dog Breeds End **********");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("**********  Game Start  **********");
            Game g = new Game() { Name = "", Price = 120 };
            if (!Validate(g, out ICollection<ValidationResult> validationResults))
            {
                if (validationResults.Where(o => o.MemberNames.Contains("Name")).Count() == 1 && validationResults.Where(o => o.MemberNames.Contains("Price")).Count() == 1)
                {
                    Console.WriteLine(String.Join("\n", validationResults.Select(o => o.ErrorMessage)));
                    Console.WriteLine("This is the expected result");
                }
            }
            else
            {
                Console.WriteLine("The Game is Valid, this is not the expected result.");
            }
            Console.WriteLine("**********  Game End  **********");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("**********  XML Parsing Start  **********");

            string xmlresults = GetXmlValue("releaseDate");
            xmlresults = GetXmlValue("author");
            if (GetXmlValue("releaseDate").Equals("1945") && GetXmlValue("author").Equals("George Orwell") && GetXmlValue("BadElement") == null)
            {
                Console.WriteLine("XML Parsing is successful");
            }
            else
            {
                Console.WriteLine("XML Parsing Failed");
            }
            Console.WriteLine("**********  XML Parsing End  **********");


            Console.WriteLine("");
            Console.WriteLine("");

            Console.WriteLine("Press any Key to end");
            Console.ReadKey();
        }

        #region * Draw Hourglass *
        // ********  Instructions
        // Implement the DrawHourglass function to generate the following output into the console window.
        //Note:  the intial // are there for comment purposes.
        //***********
        // *********
        //  *******
        //   *****
        //    ***
        //     *
        //    ***
        //   *****
        //  *******
        // *********
        //***********
        private static void DrawHourglass()
        {
        }
        #endregion * Draw Hourglass *

        #region * Fibonacci Sequence *
        // ********  Instructions
        //Implement the FibonacciSequence function to generate the Fibonacci sequence out to the console.
        //This function will stop calling after 10 interations.
        //The implementation of this function cannot use any loops and can only use if/else statements and/or recursive calls.
        //The Fibonacci sequence is 0,1,1,2,3,5,8,13,21,34 .. The next number is generated by adding the previous 2 numbers
        //The expected output is 0,1,1,2,3,5,8,13,21,34
        private static void FibonacciSequence(int val1, int val2, int callCount)
        {
        }

        #endregion * Fibonacci Sequence *

        #region * Abstract Implementation *
        // ********  Instructions 
        // Create a class called CSharpDeveloper that implements the Developer abstract class.
        // The new class will take in the developers name from the console on line 22 as a paramenter to the constructor and set the Name property
        // The StartCoding function will write out the developers name and a message about their code to the console.
        // For example:  If I enter Bob for the developers name, the output would be "Bob is writing C# code"
        // To execue the code, uncomment lines 38, 39, and 40, then execute the program.
        public abstract class Developer
        {
            public string Name { get; set; }
            public abstract void StartCoding();

        }

        #endregion * Abstract Implementation *

        #region * Alert Service *
        // ********  Instructions 
        //Refactor the AlertService and AlertDAO classes to implement Inversion of Control/Dependency Injection:
        //Create a new interface, named IAlertDAO, that contains the same methods as AlertDAO.
        //AlertDAO should implement the IAlertDAO interface.
        //AlertService should have a constructor that accepts IAlertDAO and assigns the local storage variable to the injected object.
        //The RaiseAlert and GetAlertTime methods should use the object passed through the constructor.
        //Uncomment lines 45-50 to execute this class implementation.

        public class AlertService
        {
            private readonly AlertDAO storage = new AlertDAO();

            public Guid RaiseAlert()
            {
                return this.storage.AddAlert(DateTime.Now);
            }

            public DateTime GetAlertTime(Guid id)
            {
                return this.storage.GetAlert(id);
            }
        }

        public class AlertDAO
        {
            private readonly Dictionary<Guid, DateTime> alerts = new Dictionary<Guid, DateTime>();

            public Guid AddAlert(DateTime time)
            {
                Guid id = Guid.NewGuid();
                this.alerts.Add(id, time);
                return id;
            }

            public DateTime GetAlert(Guid id)
            {
                return this.alerts[id];
            }
        }

        #endregion  * Alert Service *

        #region * Dog Breeds *
        // ********  Instructions 
        //Refactor the GetDogsBiggerThanWeight function to return all of the dog objects as a list where the Dog objects AverageWeight is greater than the minimumWeight parameter passed in.
        //This function should also sort the returning list by the BreedName.
        //The contents of the GetDogsBiggerThanWeight function should be no more than one line long and should not have an explicit loop I.e foreach(var d in DogBreeds){etc...}.
        public class Dog
        {
            public string BreedName { get; set; }
            public int AverageWeight { get; set; }
        }

        private static readonly List<Dog> DogBreeds = new List<Dog>();

        public static List<Dog> GetDogsBiggerThanWeight(int minimumWeight)
        {
            return new List<Dog>();
        }

        #endregion * Dog Breeds *

        #region * Games *
        // ********  Instructions 
        // Apply Data Annotations to the Game class properties to meet the following requirements.
        // Name is a required field.
        // Price must be between 0 and 100
        public class Game
        {
            public string Name { get; set; }
            public decimal Price { get; set; }
        }
        static bool Validate<T>(T obj, out ICollection<ValidationResult> results)
        {
            results = new List<ValidationResult>();

            return Validator.TryValidateObject(obj, new ValidationContext(obj), results, true);
        }
        #endregion * Games *

        #region * XML Parsing *
        // ********  Instructions 
        // Given the following xml string, fill out the contents of the GetXmlValue function so it returns the
        // correct value in the xml based on the element name or attribute name passed into the function.
        // If the element name or attribute name does not exist, the function should return null
        // for example if the value "name" is passed into the function the funtion will return "Animal Farm"

        private static readonly string xmlContent = "<book isHarback=\"true\" releaseDate=\"1945\"><name>Animal Farm</name><author>George Orwell</author><price>14.19</price></book>";

        public static string GetXmlValue( string elementOrAttributeName)
        {
            string retVal = string.Empty;

            return retVal;
        }

        #endregion * XML parsing *

    }
}
